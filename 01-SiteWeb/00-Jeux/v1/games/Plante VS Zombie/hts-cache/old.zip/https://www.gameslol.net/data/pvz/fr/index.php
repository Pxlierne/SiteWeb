<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Plants vs Zombies</title>
<script src="/data/ruffle/ruffle.js?040325"></script></head>
<body>
<div align="center">
  <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="100%" height="100%" id="pvz" menu="false" align="middle">
    <param name="allowScriptAccess" value="sameDomain" />
    <param name="movie" value="pvz.swf" />
    <param name="quality" value="best" />
	<param name="wmode" value="direct" />
    <param name="bgcolor" value="#F1F1F1" />
    <embed src="pvz.swf" quality="best" bgcolor="#F1F1F1" width="100%" height="100%" name="pvz" menu="false" align="middle" wmode="direct" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
  </object>
</div>
</body>
</html>